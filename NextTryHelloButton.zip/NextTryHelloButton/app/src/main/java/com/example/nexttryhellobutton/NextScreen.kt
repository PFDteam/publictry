package com.example.nexttryhellobutton

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class NextScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_next_screen)
    }
}